﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
namespace NPrintingScheduler.App_Code
{
    public class DbRepository
    {
        /// <summary>
        /// Get GetReportDetails Details
        /// </summary>
        /// <returns></returns>
        public static string GetReportDetails()
        {
            return "App.ExecuteNprintingTask";
        }
    }
}
